source('visualization.R')
source('eva_visa.R')
library(knitr)
library(kableExtra)
library(formattable)
# Project 2

# MSE 
MSE_pc <- NULL
MAE_pc <- NULL
elpd_pc <- NULL
WD_pc <- NULL

MSE_ni <- NULL
MAE_ni <- NULL
elpd_ni <- NULL
WD_ni <- NULL

results <- NULL 
Name <- names(simus)[7:12]
pnum <- c(100, 250)
anum <- c(2,5,10)

for(paramname in Name){
  for (anumm in anum) {
    for(pnumm in pnum){
      param <- simus[[paramname]][[1]]
      filesave <- paste0(paramname, "-", "NPoints", pnumm , "NAreas", anumm)
      result <- read.csv(file = paste0("~/Documents/Project2/Preferential Sampling 2/PSmelding/results/ME", filesave, ".csv"),header = T, sep="")
      result$range <- param$scl
      data <- as.data.frame(cbind(Areas = anumm^2, Points = pnumm, Scenario =paramname, prior = 0, beta1 = param$beta1), stringsAsFactors = T)
      m <- cbind(data,result)
      results <- rbind(results,m)
    }
  }
}
Name <- names(simus)[1:6]
for(paramname in Name){
  for (anumm in anum) {
    for(pnumm in pnum){
      param <- simus[[paramname]][[1]]
      filesave <- paste0(paramname, "-", "NPoints", pnumm , "NAreas", anumm)
      result <- read.csv(file = paste0("~/Documents/Project2/Preferential Sampling 2/PSmelding/results/ME", filesave, ".csv"),header = T, sep="")
      result$range <- param$scl
      data <- as.data.frame(cbind(Areas = anumm^2, Points = pnumm, Scenario =paramname, prior = 1, beta1 = param$beta1), stringsAsFactors = T)
      m <- cbind(data,result)
      results <- rbind(results,m)
    }
  }
}

fnplot <- function(df.long, points,type, pc = T){
   df.long$Model <- as.factor(df.long$Model)
  # levels(df.long$Model) <- c("Geostat", "Melding", 'PSgeo', 'PSmelding')
  d1 <- df.long%>% dplyr::filter(beta1 == 0)
  d2 <- df.long%>% dplyr::filter(beta1 == 1)
  #p1 = ggplot(final, aes(x = Point, y= MSE, fill=Method)) + geom_boxplot() +ggtitle(title)+ xlab("Number of points")+ theme(text = element_text(size = 22)) +   theme(legend.text = element_text(size=30), legend.title = element_text(size=30))
  g1 <- ggplot(data = d1) + geom_boxplot(aes_string(x = 'as.factor(range)', y= type , fill= 'Model' )) + 
    facet_wrap(facets = ~Areas, nrow = 1, ncol = 3,labeller = "label_both")+ xlab("Spatial range beta = 0") + theme_bw() + theme(strip.text.x = element_text(size = 20), legend.position = "top", legend.direction = "horizontal", legend.text = element_text(size = 20), axis.text = element_text(size = 20), axis.title = element_text(size = 20))
  g2 <- ggplot(data = d2) + geom_boxplot(aes_string(x = 'as.factor(range)', y= type, fill= 'Model' ))  +  
    # scale_y_continuous(limits = quantile(d2[[y]], c(0.005, 0.995))) + 
    facet_wrap(facets = ~Areas, nrow = 1, ncol = 3,labeller = "label_both")+ xlab("Spatial range beta = 1") + theme_bw() + theme(strip.text.x = element_text(size = 20), legend.position = "top", legend.direction = "horizontal", legend.text = element_text(size = 20), axis.text = element_text(size = 20), axis.title = element_text(size = 20))
  
  if(pc){png(paste0(type, 'pc',points,'.png'), width = 1280, height = 700)}
  if(!pc){png(paste0(type, 'default',points,'.png'), width = 1280, height = 700)}
  print(ggpubr::ggarrange(g1,g2, nrow = 2,common.legend = T))
  dev.off()
}

data1 = results%>% dplyr::filter(prior == 0 & Model %in% c('Melding', 'PS_geo', 'PS_melding')& Points == 100 & beta1 == 1) 
data2 = results%>% dplyr::filter(prior == 0 & Model %in% c('Melding', 'PS_geo', 'PS_melding')& Points == 100 & beta1 == 0) 

table1 <- data1 %>% group_by(Model,Areas, range) %>%
  summarise(
    MSE =paste0(round(mean(MSE),digits=2),' ','(',round((unname(quantile(MSE, c(0.05)))),digits=2),' ',round((unname(quantile(MSE, c(0.975)))),digits=2),')'),
    MAE =paste0(round(mean(MAE),digits=2),' ','(',round((unname(quantile(MAE, c(0.05)))),digits=2),' ',round((unname(quantile(MAE, c(0.975)))),digits=2),')'),
    WD =paste0(round(mean(WD),digits=2),' ','(',round((unname(quantile(WD, c(0.05)))),digits=2),' ',round((unname(quantile(WD, c(0.975)))),digits=2),')')
  )      
table1
table2 <- data2 %>% group_by(Model,Areas, range) %>%
  summarise(
    MSE =paste0(round(mean(MSE),digits=2),' ','(',round((unname(quantile(MSE, c(0.05)))),digits=2),' ',round((unname(quantile(MSE, c(0.975)))),digits=2),')'),
    MAE =paste0(round(mean(MAE),digits=2),' ','(',round((unname(quantile(MAE, c(0.05)))),digits=2),' ',round((unname(quantile(MAE, c(0.975)))),digits=2),')'),
    WD =paste0(round(mean(WD),digits=2),' ','(',round((unname(quantile(WD, c(0.05)))),digits=2),' ',round((unname(quantile(WD, c(0.975)))),digits=2),')')
  )      
table2
fnPredictMeldingPS()
table <- left_join(table1, table2, by = c("Model" , "Areas", "range"), suffix = c(" PS ", " Non PS") )

table%>%
  kbl(caption = "Evaluation results of the Bayesian melding, Preferential geostatistcal, and Preferential melding models, the mean of the scores and its 95% quantile interval are shown ",
      format = "latex") %>%
  kable_classic() %>%
 add_header_above(c(" " =3, "PS" = 3, "Non PS" = 3))

data = results%>% dplyr::filter(prior == 1 & Model %in% c('Melding', 'PS_geo', 'PS_melding')& Areas == 4 & beta1 == 1) %>% mutate(theta = 1/range)
fnMplot2(data, 4, pc = T)
fnMplot2(data, 25, pc = F)

# generate paramter results -----------------------------------------------
library(scoringutils)
library(tidyverse)
Name <- names(simus)
pnum <- c(100, 250)
anum <- c(2,5,10)

fnsummary <- function(pa_name, true_value, input){
  summary <- NULL
  for(paramname in Name){
    for(anumm in anum){
      for(pnumm in pnum){
        param <- simus[[paramname]][[1]]
        filesave <- paste0(paramname, "-", "NPoints", pnumm , "NAreas", anumm)
        ps_df <- read.csv(file = paste0("results/Est_", input ,filesave, ".csv"), skip = 1, head = FALSE, sep=" ")
        colnames(ps_df) <- c("parameter", "mean", "sd", "lower", "upper", 'mode')
        psm_mu <- ps_df %>% dplyr::filter(parameter == pa_name) %>% mutate(cover =cbind( lower <= true_value & upper >= true_value)) %>% 
          mutate(Inscore = interval_score(0,lower, upper, 95)) %>% mutate(Areas = anumm^2, Points = pnumm, Scenario =paramname)
        result <- psm_mu %>% group_by(Scenario,Areas,Points, parameter) %>% summarise(B_mean = mean(mean), Mean_Inscore = mean(Inscore), coverP = sum(cover)/nrow(psm_mu))
        summary <- as.data.frame(rbind(summary, result))
      }}
  }
  return(summary)
}


bo_psmelding = fnsummary("b0", 0, "psmelding" )
bo_melding = fnsummary("b0", 0, "melding" )
bo_psgeo = fnsummary("b0", 0, "psgeo" )


gamma_psmelding = fnsummary("Beta for j", 1, "psmelding" )
gamma_psgeo = fnsummary("Beta for j", 1, "psgeo" )

res <- fnPredictMelding(depoint, dearea, dppoint = depoint, boundaryregion = boundaryregion)
result <- res[[3]]
result$misc$configs$config[[1]]$Qinv
