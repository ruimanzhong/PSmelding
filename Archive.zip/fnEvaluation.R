fnEvaluation <- function(res, truesurface_sf, pnum, anum,index, sig.err) {
  # if(!"Cluster" %in% names(truesurface_sf)) {truesurface_sf$Cluster <- rep(1, nrow(truesurface_sf)) }
  len <- length(res)-1
  names <- names(res)[1:len]
  n <- nrow(truesurface_sf)
  ME <- lapply(names, function(name) return(as.data.frame (cbind(Index = index, Model = name, MSE = mean((res[[name]][[1]][["pred_mean"]] - truesurface_sf$true)^2), MAE = mean(abs(res[[name]][[1]][["pred_med"]] - truesurface_sf$true)),
                                                                 elpd = 0, 
                                                  WD = mean(((res[[name]][[1]][["pred_mean"]] - truesurface_sf$true)^2) + res[[name]][[1]][["sd"]]^2 + sig.err - 2* (sig.err* (res[[name]][[1]][["sd"]]^2)))))))
  
  
  MEE <- as.data.frame(rbind(ME[[1]],ME[[2]],ME[[3]]))
  return(MEE)
}

# fnELPD <- function(res,paramname){
#   elpd <- try(mean(inla.group.cv(res)[["cv"]], na.rm = T), silent = T)
#   if(class(elpd) == "try-error"){
#     save(res,turesirface_sf, file = paste0("error/",res[[name]],paramname,pnum,anum,".RData"))
#     elpd <- NA}
#   return(elpd)
#   
# }

fnestimate <-function(res){
  len <- length(res)-1
  names <- names(res)[1:len]
  e <- lapply(names, function(name) rbind(res[[name]][[3]][["summary.fixed"]][,c(1,2,3,5,6)], res[[name]][[3]][["summary.hyperpar"]][,c(1,2,3,5,6)]))
  names(e) <- names
  return(e)
}

fn_microegodic_para <- function(res){
  len <- length(res)-1
  names <- names(res)[1:len]
  e <- lapply(names, function(name) rbind(res[[name]][[3]][['misc']][['configs']][['config']][[1]][['theta']], res[[name]][[3]][["summary.hyperpar"]][,c(1,2,3,5,6)]))
  
  names(e) <- names
  return(e)
}

fn_hyper_combine <- function(inla_res){
  n <- length(inla_res[['misc']][['configs']][['config']])
  for (i in 1:n)
  {
    
  }
  return(margin_para)
}
# Other -------------------------------------------------------------------

makeNamedList <- function(...) {
  structure(list(...), names = as.list(substitute(list(...)))[-1L])
}
