# Make sure RandomFields and INLA package work
source('header.R')

# Number of points and number of areas
pnum <- c(100, 250)
anum <- c(2,5,10)
N= 100
